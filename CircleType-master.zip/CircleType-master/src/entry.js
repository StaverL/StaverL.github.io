import 'core-js/fn/array/from';
import CircleType from './class';

module.exports = CircleType;
